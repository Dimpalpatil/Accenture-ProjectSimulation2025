const express=require('express');
const routes=express.Router();
const pizza=require('./Model/menuModel');
const toppings=require('./Model/toppingsModel');

routes.get("/menu",async(req,res)=>{
    try{
        const menu= await pizza.find();
        res.json(menu)
    }catch(err){
        res.status(500).json({message:"error in fetching data"})
    }
});

routes.get("/toppings",async (req,res)=>{
    try{
        const toppings= await toppings.find();
        res.json(toppings)
    }catch(err){
        res.status(500).json({message:"error in fetching data"})
    }
})
module.exports=routes;