// menuModel.js
const mongoose = require("mongoose");

// Ingredient Schema
const ingredientSchema = new mongoose.Schema({
  id: String,
  iname: String,
});

// Topping Schema (inside menu)
const toppingSchema = new mongoose.Schema({
  id: String,
  tname: String,
  price: String,
});

// Menu Schema
const menuSchema = new mongoose.Schema({
  id: String,
  type: String,
  price: String,
  name: String,
  image: String,
  description: String,
  ingredients: [ingredientSchema],
  topping: [toppingSchema],
});

// Export model
module.exports = mongoose.model("Menu", menuSchema);
