// toppingModel.js
const mongoose = require("mongoose");

const toppingSchema = new mongoose.Schema({
  id: String,
  tname: String,
  price: String,
  image: String,
});

module.exports = mongoose.model("Topping", toppingSchema);
