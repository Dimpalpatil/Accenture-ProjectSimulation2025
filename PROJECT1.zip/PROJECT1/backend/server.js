const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const fs = require("fs");

const Menu = require("./Model/menuModel");
const Topping = require("./Model/toppingsModel");
const routes=require("./routing")
require("./db");


const app = express();
app.use(cors());
app.use(express.json());
app.use("/",routes)


// Insert JSON data into MongoDB (run once)
async function insertData() {
  try {
    const menuRaw = fs.readFileSync("menu.json", "utf-8");
    const toppingRaw = fs.readFileSync("toppings.json", "utf-8");

    const menuData = JSON.parse(menuRaw);
    const toppingData = JSON.parse(toppingRaw);

    await Menu.deleteMany({});
    await Topping.deleteMany({});

    await Menu.insertMany(menuData);
    await Topping.insertMany(toppingData);

    console.log("Data inserted successfully!");
  } catch (error) {
    console.error(" Error inserting data:", error.message);
  }
}

// Uncomment this line to insert data once
// insertData();

app.listen(3000, () => console.log(" Server running on port 3000"));
